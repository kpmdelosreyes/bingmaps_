<?php /* Smarty version Smarty-3.0.6, created on 2011-11-16 13:58:20
         compiled from "./templates/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17169420654ec350fc8ab8f7-69299511%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3a4f6f0d327fc7bc3ea86f63906a1bf934ca50c7' => 
    array (
      0 => './templates/footer.tpl',
      1 => 1321423097,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17169420654ec350fc8ab8f7-69299511',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
    </body>
</html>